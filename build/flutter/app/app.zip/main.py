import flet as ft
import os
import sqlite3

class TextEditing(ft.TextField):
    def __init__(self, id) -> None:
        super().__init__()
        self.textfield = ft.TextField(multiline= True,
                                      autofocus= True,
                                      border=ft.InputBorder.NONE,
                                      min_lines=40,
                                      text_style=ft.TextStyle(font_family="SFProDisplay-Medium"),
                                      on_change=self.save_text,
                                      content_padding=10,
                                      cursor_color="orange",
                                      hint_text="Напишите что-нибудь...",
                                      expand= True)
        self.namefield = ft.TextField(border=ft.InputBorder.NONE,
                                      min_lines=1,
                                      max_lines=1,
                                      max_length=28,
                                      text_size=20,
                                      text_style=ft.TextStyle(font_family="SFProDisplay-Bold"),
                                      on_change=self.save_name,
                                      content_padding=10,
                                      hint_text="Название",
                                      cursor_color="orange")
        
        self.current_name = "save.txt"
        self.id = id
        self.data = get_info(self.id)
    def save_text(self, e: ft.ControlEvent):
        update_text(self.id, self.textfield.value)
    
    def save_name(self, e:ft.ControlEvent):
        update_Name(self.id, self.namefield.value)

    def read_text(self):
        self.textfield.value = self.data[2]
    
    def read_name(self):
        self.namefield.value = self.data[1]
    
    def build(self):
        self.read_text()
        self.read_name()
        return ft.Column(controls=[self.namefield, self.textfield], spacing=-10)

def database_txt():
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Task (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT Not NULL,
    status BOOLEAN NOT NULL DEFAULT FALSE,
    priorety BOOLEAN NOT NULL DEFAULT FALSE
    )
    ''')

    connection.commit()
    connection.close()

    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Txt (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT Not NULL,
    text TEXT Not NULL,
    priorety BOOLEAN NOT NULL DEFAULT FALSE
    )
    ''')
    
    connection.commit()
    connection.close()

def new_note_to_database(name, text, priorety):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'INSERT INTO Txt (name, text, priorety) VALUES (?, ?, ?)', (name, text, priorety))

    cursor.execute(f'SELECT id FROM Txt WHERE name = ? AND text = ?', (name, text))
    result = cursor.fetchone()
    print(result)
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return result[0]
def new_task_to_database(text, status, priorety):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'INSERT INTO Task (text, status, priorety) VALUES (?, ?, ?)', (text, status, priorety))

    cursor.execute(f'SELECT id FROM Task WHERE text = ?', (text, ))
    result = cursor.fetchone()
    print(result)
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return result[0]

def update_text(id, text):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Txt SET text = ? WHERE id = ?', (text, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
def update_task(id, text):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Task SET text = ? WHERE id = ?', (text, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()

def update_task_do_status(id, status):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Task SET status = ? WHERE id = ?', (status, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
def update_task_priorety(id, priorety):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Task SET priorety = ? WHERE id = ?', (priorety, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
def update_note_priorety(id, priorety):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Txt SET priorety = ? WHERE id = ?', (priorety, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
def update_Name(id, name):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'UPDATE Txt SET name = ? WHERE id = ?', (name, id))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()

def get_info(id):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'SELECT * FROM Txt WHERE id = ?', (id,))
    result = cursor.fetchone()
    
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return result
def get_info_task(id):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'SELECT * FROM Task WHERE id = ?', (id,))
    result = cursor.fetchone()
    
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return result

def get_all_id():
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute("SELECT id FROM Txt")
    ids = [row[0] for row in cursor.fetchall()]
    
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return ids
def get_all_id_task():
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute("SELECT id FROM Task")
    ids = [row[0] for row in cursor.fetchall()]
    
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
    return ids

def delete_note(id):
    connection = sqlite3.connect('txtFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'DELETE FROM Txt WHERE id = ?', (id, ))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()
def delete_task(id):
    connection = sqlite3.connect('TaskFiles.db')
    cursor = connection.cursor()

    # Создаем таблицу Txt
    cursor.execute(f'DELETE FROM Task WHERE id = ?', (id, ))
    # Сохраняем изменения и закрываем соединение
    connection.commit()
    connection.close()

def main(page:ft.Page):

    database_txt()

    global container_task_color

    container_task_color = ft.Colors.GREY_900
    
    page.window.height = 640 # Временное решение, чтобы понимать как приложение выглядит в вертикальном формате
    page.window.width = 360

    page.fonts = {
        "SFProDisplay-Bold": "assets/fonts/SFProDisplay-Bold.ttf",
        "SFProDisplay-Medium": "assets/fonts/SFProDisplay-Medium.ttf"
    }

    page.theme_mode = "dark"
    
    page.scroll = True

    def Notes_Column_upd(page, column):
        if page.theme_mode == "dark":
            clr = "white",
            container_color = ft.Colors.GREY_900
        else:
            clr = "black",
            container_color = ft.Colors.GREY_300
        
        column.controls.clear()
        notes_priorety_column.controls.clear()
        
        all_id = get_all_id()
        for id in all_id:
            data_note = get_info(id)
            name = data_note[1]
            txt = data_note[2]
            priorety = data_note[3]
            sym_size = 15

            if txt == "" and name == "":
                delete_note(id)
                continue
            if priorety == 1:
                    priorety = True
            else:
                priorety = False

            sym = 35
            
            star = ft.IconButton(icon=ft.Icons.STAR_BORDER, selected_icon=ft.Icons.STAR, selected=priorety, on_click=lambda e, idd = id: change_priorety_note(e, idd), icon_size=18)

            text = ft.Container(
                content= ft.Row(
                    controls=
                    [
                        ft.Column(
                                controls=[
                                    ft.Text(value= name, size=sym_size, font_family="SFProDisplay-Bold", max_lines=1, color=clr),
                                    ft.Text(value= txt, font_family="SFProDisplay-Medium", max_lines=1, color=clr)
                                ],
                                spacing=0,
                                expand=True
                            ),
                        star
                    ]
                ),
                margin= ft.margin.only(left=20),
                alignment=ft.alignment.bottom_left,
                
            )

            MiniNotes = ft.Container(
                        bgcolor=container_color,
                        height = page.height / 14,
                        border_radius=5,
                        content= text,
                        alignment=ft.alignment.center_left,
                        margin= ft.margin.symmetric(horizontal=5),
                        on_click=open_note,
                        data = id,
                        expand=True
                    )
            print(clr, container_color)
            if priorety:
                notes_priorety_column.controls.append(MiniNotes)
            else:
                column.controls.append(MiniNotes)
            page.update()

    def change_theme(e):
            if page.theme_mode == "dark":
                page.theme_mode = "light"
                app_bars["main_task"].bgcolor = ft.Colors.SURFACE 
                bottom_add_task_btn.bgcolor = ft.Colors.GREY_300
                bg_task_color = ft.Colors.GREY_300
            else:
                page.theme_mode = "dark"
                app_bars["main_task"].bgcolor = ft.Colors.SURFACE 
                bottom_add_task_btn.bgcolor = ft.Colors.GREY_900
                bg_task_color = ft.Colors.GREY_900
            print("change_theme do it")
            Notes_Column_upd(page, notes_column)
            page.update()
        
    def set_main_screen(e):
        page.clean()
        
        Notes_Column_upd(page, notes_column)

        change_bottom_bar("main_notes")
        
        page.add(main_screen)

    def change_bottom_bar(state):
        page.bottom_appbar = app_bars[state]
        
    def create_note(e):
        page.clean()

        id = new_note_to_database("", "", False)
        text_editor = TextEditing(id)

        change_bottom_bar("do_notes")

        page.add(opened_note_page_element(text_editor=text_editor))
    
    def open_note(e):
        page.clean()

        id = e.control.data
        text_editor = TextEditing(id)
        
        change_bottom_bar("do_notes")
        
        page.add(opened_note_page_element(text_editor=text_editor))
    
    def opened_note_page_element(text_editor):
        opened_note = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls = [
                                ft.IconButton(ft.CupertinoIcons.BACK, on_click=set_main_screen),
                                ft.IconButton(ft.Icons.MENU_OPEN)
                            ]
                            ),
                    expand=True,
                ),
                text_editor.build()
            ], 
        )
        return opened_note
    
    def add_all_tasks():
            ids = get_all_id_task()

            task_column.controls.clear()
            task_priorety_column.controls.clear()

            
            for id in ids:
                info = get_info_task(id)
                text = info[1]
                priorety = info[3]

                if (text == ""):
                    delete_task(id)
                    continue
                if priorety == 1:
                    priorety = True
                else:
                    priorety = False
                if info[2] == 1:
                    did_it = True
                else: 
                    did_it = False

                print(did_it)

                block_cont = ft.Container(
                    content= ft.Row(
                        controls=[
                            ft.Checkbox(
                                value = did_it,
                                shape=ft.RoundedRectangleBorder(radius=10),
                                on_change=lambda e, task_id=id, status=did_it: update_task_do_status(task_id, not status)
                            ),
                            ft.Text(value=text, font_family="SFProDisplay-Medium", max_lines=3, expand=True, no_wrap=False),
                            ft.IconButton(icon=ft.Icons.STAR_BORDER, selected_icon=ft.Icons.STAR, selected=priorety, on_click=lambda e, idd = id: change_priorety_task(e, idd), icon_size=18)
                        ], 
                    ),
                    margin=ft.margin.symmetric(horizontal=10),
                )
                block = get_theme_container_task(block_cont)
                block.data = id
                
                if priorety:
                    task_priorety_column.controls.append(block)
                else:
                    task_column.controls.append(block)
                
                page.update()
    
    def get_theme_container_task(block_cont):
        if page.theme_mode == "light":
            block = ft.Container(
                    content= block_cont,
                    height=page.height/14,
                    bgcolor= ft.Colors.GREY_300,
                    border_radius=5,
                    on_click= set_task_settings,
                    data=1
                )
        else:
            block = ft.Container(
                    content= block_cont,
                    height=page.height/14,
                    bgcolor= ft.Colors.GREY_900,
                    border_radius=5,
                    on_click= set_task_settings,
                    data=1
                )
        return block

    
    def new_task(e):
        page.overlay.append(create_task_menu)
        create_task_menu.open = True
        task_space_to_enter_name.data = new_task_to_database(task_space_to_enter_name.value, status=False, priorety=False)

        page.update()
    
    def change_name_task_on_dismissed(e):
        id = task_space_to_enter_name.data
        update_task(id, task_space_to_enter_name.value) 
        task_space_to_enter_name.value = ""
        add_all_tasks()

    def get_theme_mode():
        if page.theme_mode == "dark":
            return "black"
        else:
            return "white"
    
    task_column = ft.Column(spacing=3)
    task_priorety_column = ft.Column(spacing=3)

    task_space_to_enter_name = ft.TextField(hint_text="Добавить задачу", hint_style=ft.TextStyle(font_family="SFProDisplay-Bold"), border=ft.InputBorder.NONE, data=1, text_style=ft.TextStyle(font_family="SFProDisplay-Medium"), expand=True, max_lines=3, max_length=50)

    ft.Icon(ft.Icons.NOTIFICATIONS, size=20, color=ft.Colors.GREY),

    create_task_menu = ft.BottomSheet(
        content= ft.Container(
                    content=ft.Column(
                        controls=
                        [
                            ft.Row(
                                controls= 
                                [
                                    ft.Icon(ft.Icons.CIRCLE_OUTLINED, size=25),
                                    task_space_to_enter_name
                                ], spacing=20
                            ),
                            ft.Row(
                                controls=
                                [
                                    ft.IconButton(ft.Icons.NOTIFICATIONS, icon_size=20, icon_color=ft.Colors.GREY),
                                    ft.IconButton(ft.Icons.CALENDAR_MONTH, icon_size=20, icon_color=ft.Colors.GREY),
                                    ft.IconButton(ft.Icons.RECYCLING_OUTLINED, icon_size=20, icon_color=ft.Colors.GREY)
                                    
                                ], spacing=30
                            )
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=10
                    ),
                height = 120,
                alignment= ft.alignment.center,
                margin=ft.margin.symmetric(horizontal=20)
        ),
        use_safe_area=True,
        shape=ft.RoundedRectangleBorder(10),
        open=False,
        maintain_bottom_view_insets_padding = True,
        on_dismiss=change_name_task_on_dismissed
    )
    top_task_menu = ft.Container(
                    content=ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            controls = [
                                ft.IconButton(icon=ft.CupertinoIcons.BACK, on_click=set_main_screen, icon_size=25), 
                                ft.Text(value = "Задачи", size=20, font_family= "SFProDisplay-Bold", color=ft.Colors.ORANGE),
                                ft.IconButton(ft.Icons.MORE_HORIZ, icon_size=25)
                            ],
                        ), alignment=ft.alignment.top_left
                )
    bottom_add_task_btn = ft.Container(
        content=ft.Row(
            controls=[
                ft.Icon(ft.Icons.ADD),
                ft.Text(value="Добавить задачу", font_family="SFProDisplay-Bold", color= ft.Colors.ORANGE)
            ]
        ),
        height=page.height/14,
        width = page.width - 40,
        bgcolor= ft.Colors.GREY_900,
        border_radius=5,
        padding=10,
        on_click=new_task
    )

    main_task = ft.Column(
        controls=
        [
            top_task_menu,
            ft.Column(
                controls=
                [
                    task_priorety_column,
                    task_column
                ], spacing=3
            )
        ], spacing=0
    )
    
    def set_todo_page(e):
        page.clean()
        change_bottom_bar("main_task")
        add_all_tasks()

        page.add(main_task)

    notes_column = ft.Column(expand=True, spacing=3)
    notes_priorety_column = ft.Column(expand=True, spacing=3)
    print(notes_column)
    Notes_Column_upd(page, notes_column)
    
    page.theme = ft.Theme(
            color_scheme=ft.ColorScheme(
                primary=ft.Colors.ORANGE,
                on_primary=ft.Colors.BLACK,
                secondary=ft.Colors.WHITE,  # Это может влиять на иконки
            )
        )    

    menu = ft.PopupMenuButton(
        content=ft.Icon(ft.Icons.MENU),
        items=[
            ft.PopupMenuItem(icon=ft.Icons.SUNNY, text= "Сменить тему", on_click=change_theme),
            ft.PopupMenuItem(icon=ft.Icons.TASK, text= "Задачи", on_click=set_todo_page)
        ]
    )
    
    top_center = ft.Column(
            controls=[
                ft.Row(alignment = "spaceBetween",
                    controls=[
                        menu,                      
                        ft.Row(
                            controls=[
                                ft.IconButton(ft.CupertinoIcons.SEARCH, icon_size=23),
                                ft.IconButton(ft.Icons.NOTIFICATIONS, icon_size=23)
                            ], spacing=1
                        )
                    ], expand=True
                ),
                ft.Container(
                    content=ft.Text( 
                        value = "Заметки",                 
                        size = 30,
                        font_family="SFProDisplay-Bold",
                        color=ft.Colors.ORANGE
                    ),
                    margin= ft.margin.symmetric(horizontal=5),
                    expand=True
                ),
                notes_priorety_column,
                notes_column
            ],
            spacing= 3,
            expand=True
        )
    
    def delete_task_user(e, id):
        delete_task(id)
        set_todo_page(e)
    
    def change_priorety_task(e, id):
        e.control.selected = not e.control.selected
        print(id)
        if e.control.selected:
            update_task_priorety(id, True)
        else:
            update_task_priorety(id, False) 
        print(e.control.selected)
        add_all_tasks()
        page.update()
    
    def change_priorety_note(e, id):
        e.control.selected = not e.control.selected
        print(id)
        if e.control.selected:
            update_note_priorety(id, True)
        else:
            update_note_priorety(id, False)
        print(e.control.selected)
        Notes_Column_upd(page, notes_column)
        page.update()


    def set_task_settings(e):
        id = e.control.data
        delete_button.on_click = lambda e: delete_task_user(e, id)
        change_bottom_bar("task_settings")

        all_info = get_info_task(id)
        
        text = all_info[1]
        status = all_info[2]
        priorety = all_info[3]

        if status == 1:
            status = True
        else:
            status = False

        if priorety == 1:
            priorety = True
        else:
            priorety = False
        
        text_delete_task = ft.Row(
        controls=[
            ft.Checkbox(
                    value = status,
                    shape=ft.RoundedRectangleBorder(radius=10),
                    on_change=lambda e, task_id=id, status=status: update_task_do_status(task_id, not status)
            ),
            ft.Text(value=text, font_family="SFProDisplay-Bold", size=20, expand=True),
            ft.IconButton(icon=ft.Icons.STAR_BORDER, selected_icon=ft.Icons.STAR, selected= priorety, on_click= lambda e: change_priorety_task(e, id), icon_size=18)
        ]
    )

        page.clean()
        page.add(ft.Column(
            controls=[
                top_delete_task,
                text_delete_task,
                interface_under_text_in_task_settings
            ], spacing=5
        ))
    
    top_delete_task = ft.Row(
        controls=[
            ft.IconButton(icon=ft.CupertinoIcons.BACK, on_click=set_todo_page, icon_size=20), 
            ft.Text(value = "Задачи", size=16, font_family= "SFProDisplay-Bold", color=ft.Colors.ORANGE)
        ], spacing=0
    )
    
    interface_under_text_in_task_settings = ft.Column(
        controls=
        [
            ft.Divider(height=1),
            ft.Container(
                content=ft.Row(
                            controls=[
                                ft.Icon(ft.Icons.NOTIFICATIONS, size=20, color=ft.Colors.GREY),
                                ft.Text(font_family="SFProDisplay-Bold", size=14, value="Напомнить", color=ft.Colors.GREY)
                            ], spacing=20
                ),
                height=page.height/14,
                margin=ft.margin.symmetric(horizontal=5)
            ),
            ft.Container(
                content=ft.Row(
                            controls=[
                                ft.Icon(ft.Icons.CALENDAR_MONTH, size=20, color=ft.Colors.GREY),
                                ft.Text(font_family="SFProDisplay-Bold", size=14, value="Добавить дату выполнения", color=ft.Colors.GREY)
                            ], spacing=20
                ),
                height=page.height/14,
                margin=ft.margin.symmetric(horizontal=5)
            ),
            ft.Container(
                content=ft.Row(
                            controls=[
                                ft.Icon(ft.Icons.RECYCLING_OUTLINED, size=20, color=ft.Colors.GREY),
                                ft.Text(font_family="SFProDisplay-Bold", size=14, value="Повтор", color=ft.Colors.GREY)
                            ], spacing=20
                ),
                height=page.height/14,
                margin=ft.margin.symmetric(horizontal=5)
            ),
        ], spacing=0
    )
    
    
    delete_button = ft.IconButton(icon=ft.Icons.DELETE, icon_size=20, icon_color=ft.Colors.GREY) 

    bottom_delete_task = ft.Row(
        controls=[
            ft.Container(),
            ft.Text(font_family="SFProDisplay-Bold",size=12, value="Создано Вт, 27 сент.", color=ft.Colors.GREY),
            delete_button
        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, spacing=0
    )
    
    # confirm_delete_cont = ft.CupertinoActionSheet(
    #     data=1,
    #     cancel=ft.CupertinoActionSheetAction(
    #         content=ft.Text("Отмена", size=20)
    #     ),
    #     actions=[
    #         ft.CupertinoActionSheetAction(
    #             content=ft.Text("Не удалять", size=20),
    #             is_default_action=True
    #         ),
    #         ft.CupertinoActionSheetAction(
    #             content=ft.Text("Удалить", size=20),
    #             is_destructive_action=True,
    #             on_click=delete_task(2)
    #         ),
    #     ]
    # )

    # delete_bottom_quest = ft.CupertinoBottomSheet(confirm_delete_cont)
    app_bars = {
        "main_notes": ft.BottomAppBar(
                        content=ft.Row(
                                        controls=[
                                            ft.Container(expand=True),
                                            ft.IconButton(ft.CupertinoIcons.MIC),
                                            ft.IconButton(ft.CupertinoIcons.ADD_CIRCLED, on_click=create_note)  
                                        ],
                                        vertical_alignment=ft.CrossAxisAlignment.START
                        ),
                        padding= ft.padding.symmetric(vertical=5, horizontal=10),
                        height = page.height/14,
                        bgcolor= ft.Colors.SURFACE 
                    ),
        "do_notes": ft.BottomAppBar(
                        content=ft.IconButton(ft.CupertinoIcons.MIC),
                        padding= ft.padding.symmetric(vertical=5, horizontal=10),
                        height = page.height/14,
                        bgcolor= ft.Colors.SURFACE 
                    ),
        "main_task": ft.BottomAppBar(
                        content=bottom_add_task_btn,
                        padding= ft.padding.symmetric(vertical=10, horizontal=10),
                        height = page.height/10,
                        bgcolor= ft.Colors.SURFACE 
                    ),
        "task_settings": ft.BottomAppBar(
                        content=bottom_delete_task,
                        padding= ft.padding.symmetric(vertical=10, horizontal=10),
                        height = page.height/10,
                        bgcolor= ft.Colors.SURFACE
                    )               
    }

    # page.appbar = ft.CupertinoAppBar(
    #     leading= ft.IconButton(ft.CupertinoIcons.BACK, icon_color="orange"),
    #     middle= ft.Text("AppBar Test"),
    #     brightness=ft.Brightness.LIGHT,
    #     enable_background_filter_blur = True,
    #     padding=1
    # )

    change_bottom_bar("main_notes")
    
    main_screen = top_center
    page.add(
        main_screen
    )

if __name__ == "__main__":
    ft.app(target= main, view=ft.AppView.FLET_APP) 